// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services','ngIOS9UIWebViewPatch','ngCordova'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleLightContent();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

  $ionicConfigProvider.platform.android.tabs.style('standard');
  $ionicConfigProvider.platform.android.tabs.position('bottom');
  $ionicConfigProvider.platform.android.navBar.alignTitle('center');
  $ionicConfigProvider.backButton.previousTitleText(false).text('');

  $stateProvider

  // .state('tour', {
  //   url: '/tour',
  //   cache: false,
  //   templateUrl: 'templates/tour.html',
  //   controller: 'TourCtrl'
  // })
//====================================================
  .state('tab', {
    url: '/tab',
    // abstract: true,
    templateUrl: 'templates/tabs.html'
  })
//====================================================
  .state('tab.game', {
    url: '/game',
    views: {
      'tab-game': {
        templateUrl: 'templates/tab-game.html',
        controller: 'GameCtrl'
      }
    }
  })
//====================================================
  .state('tab.forums', {
    url: '/forums/:fid/:defaultFid',
    views: {
      'tab-game': {
        templateUrl: 'templates/tab-forums.html',
        controller: 'ForumsCtrl'
      }
    }
  })
    // .state('tab.forum-post', {
    //   url: '/post',
    //   views: {
    //     'tab-game': {
    //       templateUrl: 'templates/forum-post.html',
    //       controller: 'PostCtrl'
    //     }
    //   }
    // })
    .state('tab.communicateFid', {
      url: '/communicateFid',
      templateUrl: 'templates/tab-forums.html'
    })
    .state('tab.noticeFid', {
      url: '/noticeFid',
      templateUrl: 'templates/tab-forums.html'
    })
    .state('tab.battleFid', {
      url: '/battleFid',
      templateUrl: 'templates/tab-forums.html'
    })
    .state('tab.customerFid', {
      url: '/customerFid',
      templateUrl: 'templates/tab-forums.html'
    })
//====================================================
  .state('tab.forum-detail', {
    url: '/forum-detail/:tid',
    views: {
      'tab-game': {
        templateUrl: 'templates/forum-detail.html',
        controller: 'ThreadCtrl'
      }
    }
  })
    .state('tab.forum-reply', {
      url: '/reply',
      views: {
        'tab-game': {
          templateUrl: 'templates/forum-reply.html',
          controller: 'ReplyCtrl'
        }
      }
    })
//====================================================
  .state('tab.personal', {
    url: '/personal',
    cache: false,
    views: {
      'tab-personal': {
        templateUrl: 'templates/tab-personal.html',
        controller: 'PersonalCtrl'
      }
    }
  })
    .state('tab.myThread', {
      url: '/myThread',
      views: {
        'tab-personal': {
          templateUrl: 'templates/tab-myThread.html',
          controller: 'MyThreadCtrl'
        }
      }
    })
    .state('tab.myReply', {
      url: '/myReply',
      views: {
        'tab-personal': {
          templateUrl: 'templates/tab-myReply.html',
          controller: 'MyReplyCtrl'
        }
      }
    })
    .state('tab.collect', {
      url: '/collect',
      views: {
        'tab-personal': {
          templateUrl: 'templates/tab-collect.html',
          controller: 'CollectCtrl'
        }
      }
    })
    .state('tab.role', {
      url: '/role',
      views: {
        'tab-personal': {
          templateUrl: 'templates/tab-role.html',
          controller: 'RoleCtrl'
        }
      }
    })
    .state('tab.myforum-detail', {
      url: '/forum-detail/:tid',
      views: {
        'tab-personal': {
          templateUrl: 'templates/forum-detail.html',
          controller: 'ThreadCtrl'
        }
      }
    })
//====================================================
  .state('tab.social', {
    url: '/social',
    views: {
      'tab-social': {
        templateUrl: 'templates/tab-social.html',
        controller: 'SocialCtrl'
      }
    }
  })
//====================================================
  .state('tab.set', {
    url: '/set',
    views: {
      'tab-set': {
        templateUrl: 'templates/tab-set.html',
        controller: 'SetCtrl'
      }
    }
  })
    .state('tab.nickname', {
      url: '/nickname',
      views: {
        'tab-set': {
          templateUrl: 'templates/nickname.html',
          controller: 'NicknameCtrl'
        }
      }
    })
    .state('tab.password', {
      url: '/password',
      views: {
        'tab-set': {
          templateUrl: 'templates/password.html',
          controller: 'PasswordCtrl'
        }
      }
    })
    .state('tab.mobile', {
      url: '/mobile',
      views: {
        'tab-set': {
          templateUrl: 'templates/mobile.html',
          controller: 'MobileCtrl'
        }
      }
    })
    .state('tab.eula', {
      url: '/eula',
      views: {
        'tab-set': {
          templateUrl: 'templates/eula.html'
        }
      }
    })
//====================================================

  $urlRouterProvider.otherwise('/tab/game');
});
