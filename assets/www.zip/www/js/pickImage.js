 $scope.images_list = [];
 // "添加附件"Event
 $scope.addAttachment = function() {
 	//nonePopover();
 	$ionicActionSheet.show({
 		buttons: [{
 			text: '相机'
 		}, {
 			text: '图库'
 		}],
 		cancelText: '关闭',
 		cancel: function() {
 			return true;
 		},
 		buttonClicked: function(index) {
 			switch (index) {
 				case 0:
 					appendByCamera();
 					break;
 				case 1:
 					pickImage();
 					break;
 				default:
 					break;
 			}
 			return true;
 		}
 	});
 };

 var pickImage = function() {
 	var options = {
 		maximumImagesCount: 1,
 		width: 800,
 		height: 800,
 		quality: 80
 	};

 	$cordovaImagePicker.getPictures(options)
 		.then(
 			function(results) {
 				if (results[0] != undefined) {
 					$scope.images_list.push(results[0]);
 					var image = document.getElementById('myImage2');
 					image.src = results[0];
 					image.width = 100;
 					image.height = 100;

 					$http.jsonp(CommonService.RootURL + 'mobile-file-getaid.action?callback=JSON_CALLBACK')
 						.success(function(response) {
 							if (response.success) {
 								$scope.valiCode = response.valiCode;
 								$scope.aid = response.aid;
 							} else {
 								$scope.valiCode = "您未登录"
 							}

 						});
 				}
 			},
 			function(error) {
 				alert('22222');
 			});

 	//多张图片选中
 	// $cordovaImagePicker.getPictures(
 	// 	function(results) {
 	// 		for (var i = 0; i < results.length; i++) {
 	// 			$scope.images_list.push(results[i]);
 	// 		}
 	// 	},
 	// 	function(error) {
 	// 		console.log('Error: ' + error);
 	// 	});

 }

 // var sendAttId = function(){
 // alert(CommonService.RootURL + 'mobile-file-getaid.action?callback=JSON_CALLBACK');
 // }

 var appendByCamera = function() {
 	var options = {
 		//这些参数可能要配合着使用，比如选择了sourcetype是0，destinationtype要相应的设置
 		quality: 100, //相片质量0-100
 		destinationType: Camera.DestinationType.FILE_URI, //返回类型：DATA_URL= 0，返回作为 base64 編碼字串。 FILE_URI=1，返回影像档的 URI。NATIVE_URI=2，返回图像本机URI (例如，資產庫)
 		sourceType: Camera.PictureSourceType.CAMERA, //从哪里选择图片：PHOTOLIBRARY=0，相机拍照=1，SAVEDPHOTOALBUM=2。0和1其实都是本地图库
 		allowEdit: false, //在选择之前允许修改截图
 		encodingType: Camera.EncodingType.JPEG, //保存的图片格式： JPEG = 0, PNG = 1
 		// targetWidth: 200, //照片宽度
 		// targetHeight: 200, //照片高度
 		mediaType: 0, //可选媒体类型：圖片=0，只允许选择图片將返回指定DestinationType的参数。 視頻格式=1，允许选择视频，最终返回 FILE_URI。ALLMEDIA= 2，允许所有媒体类型的选择。
 		cameraDirection: 0, //枪后摄像头类型：Back= 0,Front-facing = 1
 		popoverOptions: CameraPopoverOptions,
 		saveToPhotoAlbum: true //保存进手机相册
 	};
 	$cordovaCamera.getPicture(options).then(function(imageData) {
 		// CommonJs.AlertPopup(imageData);
 		var image = document.getElementById('myImage');
 		image.src = imageData;
 		image.width = 100;
 		image.height = 100;
 		// image.src = "data:image/jpeg;base64," + imageData;
 	}, function(err) {
 		// error
 		CommonJs.AlertPopup(err.message);
 	});
 }


 // 上传文件
 $scope.upload = function() {
 	// var ft = new FileTransfer();
 	// alert(ft);
 	// ft.upload($scope.images_list[0], CommonService.RootURL + 'mobile-file-upload.action?callback=JSON_CALLBACK&aid=' + $scope.aid + '&valiCode=' + $scope.valiCode, function(data) {

 	// 	alert(data.response);
 	// 	var resp = JSON.parse(data.response);
 	// }, function(error) {
 	// 	$ionicLoading.hide();
 	// }, options);

 	//新建文件上传选项，并设置文件key，name，type
 	var options = new FileUploadOptions();
 	options.fileKey = "ffile";
 	options.fileName = $scope.images_list[0].substr($scope.images_list[0].lastIndexOf('/') + 1);
 	options.mimeType = "image/jpeg";
 	//用params保存其他参数，例如昵称，年龄之类
 	var params = {};
 	params['aid'] = $scope.aid;
 	params['valiCode'] = $scope.valiCode;
 	//把params添加到options的params中
 	options.params = params;
 	//新建FileTransfer对象
 	var ft = new FileTransfer();
 	//上传文件
 	ft.upload(
 		$scope.images_list[0],
 		encodeURI(CommonService.RootURL + 'mobile-file-upload.action'), //把图片及其他参数发送到这个URL，相当于一个请求，在后台接收图片及其他参数然后处理
 		uploadSuccess,
 		uploadError,
 		options);
 	//upload成功的话
 	function uploadSuccess(r) {
 		var resp = JSON.parse(r.response);
 		if (resp.success) {
 			var image = document.getElementById('myImage_remote');
 			image.src = CommonService.RootURL + '/attchtmp/' + resp.picName;
 			image.width = 50;
 			image.height = 50;
 			var uploadFiles = {};
 			uploadFiles[$scope.aid] = resp.picName;
 			var attachInfo = JSON.stringify(uploadFiles);
 			$scope.attachInfo = attachInfo;
 		} else {
 			alert(r.response.msg);
 		}
 		var resp = JSON.parse(r.response);
 	}
 	//upload失败的话
 	function uploadError(error) {}
 }