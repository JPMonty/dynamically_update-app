﻿angular.module('starter.controllers', ['ionic','ui.router', 'ui.validate', 'monospaced.elastic'])

.filter('unsafe', function($sce) {
  return $sce.trustAsHtml;
})

// .filter('myFilter', function(){
//     return function(data, parameter){
//         var filtered=[];
//         for(var i=0;i<data.length;i++){
//                 if(i%parameter==0)
//                     filtered.push(data[i]);
//         }
//         return filtered;
//     }
// })

.directive('hideTabs', function($rootScope) {
  return {
    restrict: 'A',
    link: function(scope, element, attributes) {
      scope.$watch(attributes.hideTabs, function(value) {
        $rootScope.hideTabs = value;
      });
      scope.$on('$destroy', function() {
        $rootScope.hideTabs = false;
      });
    }

  };
 })

.directive('compile', ['$compile', function ($compile) {
    return function(scope, element, attrs) {
        scope.$watch(
            function(scope) {
                // watch the 'compile' expression for changes
                return scope.$eval(attrs.compile);
            },
            function(value) {
                // when the 'compile' expression changes
                // assign it into the current DOM
                element.html(value);

                // compile the new DOM and link it to the current
                // scope.
                // NOTE: we only compile .childNodes so that
                // we don't get into infinite loop compiling ourselves
                $compile(element.contents())(scope);
            }
        );
    };
}])



// .directive('hideTabs', function($rootScope) {
  // return {
  //   restrict: 'A',
  //   link: function(scope, element, attributes) {
  //     scope.$on('$ionicView.beforeEnter', function() {
  //       scope.$watch(attributes.hideTabs, function(value) {
  //         $rootScope.hideTabs = value;
  //       });
  //     });
  //     scope.$on('$ionicView.beforeLeave', function() {
  //       $rootScope.hideTabs = false;
  //     });
  //   }
  // };
// })

// .directive('focusMe', function($timeout) {
  // return {
  //   link: function(scope, element, attrs) {
  //     $timeout(function() {
  //       element[0].focus();
  //       if (ionic.Platform.isAndroid()) {
  //         cordova.plugins.Keyboard.show();
  //       }
  //     }, 150);
  //   }
  // };
// })

.run(['$window', '$rootScope', function($window, $rootScope) {
  $rootScope.goBack = function() {
    $window.history.back();
  }
}])

.run(function($ionicPlatform, $location) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
  });

  // var firstVisit = localStorage.getItem('firstVisit');
  // if (!firstVisit) {
    $location.url('/tour');
  // }
})

.controller('TourCtrl', function($scope, $location, $timeout) {

  //====================================================
  // $scope.enterbbs = function () {
  //   // localStorage.setItem('firstVisit', true);
  //   // $timeout(function() {
  //     console.log('tour');
  //     $location.url('/tab/game');
  //   // }, 150);
  // }
  //====================================================
})

.controller('GameCtrl', function($scope, $http, $rootScope, CommonService, GameService) {
  var game = {
    url: CommonService.RootURL + 'index.htm?callback=JSON_CALLBACK&version=3&type=',
    pc: ['pc', 0],
    mobile: ['mobile', 1]
  };
  // 
  $http.jsonp(game.url + game.pc[1])
    .then(function(response) {
      GameService.set(game.pc[0], response.data);
      $scope.pcGames = GameService.get(game.pc[0]);
      $rootScope.islogin = response.data.isLogin;
    })
    .then(function() {
      $http.jsonp(game.url + game.mobile[1])
        .success(function(response) {
          GameService.set(game.mobile[0], response);
          $scope.mGames = GameService.get(game.mobile[0]);
        })
    });
  // 
  $scope.download=function(url) {
    //window.open(url, '_blank', 'location=no');//ios
    cordova.exec(function(){}, function(error){alert(error)}, "download","call", [url]);//android
  }
})

.controller('ForumsCtrl', function($scope, $http, $rootScope, $stateParams, $q, $ionicModal, CommonService, LoginService, ForumsService) {
  $scope.forum = {
    fid: $stateParams.fid,
    otherSubFidsUrl: function() {
      return CommonService.RootURL + 'subIndex.htm?callback=JSON_CALLBACK&fid=' + this.fid
    },
    curSubFid: $stateParams.defaultFid,
    curSubFidUrl: function() {
      return CommonService.RootURL + 'listThreads.htm?callback=JSON_CALLBACK&fid=' + this.curSubFid + '&page='
      // return CommonService.RootURL + 'listNewThreads.htm?callback=JSON_CALLBACK&fid=' + this.curSubFid + '&page='
    },
    firstPage: 1,
    communicateFidPages: 1,
    noticeFidPages: 1,
    battleFidPages: 1,
    customerFidPages: 1,
    moreCommunicate: true,
    moreNotice: false,
    moreBattle: false,
    moreCustomer: false
  };
  $scope.showDetails = true;
  $rootScope.communicates = [];
  $rootScope.notices = [];
  $rootScope.battles = [];
  $rootScope.customers = [];

  $http.jsonp($scope.forum.otherSubFidsUrl())
    .then(function(response) {
      $scope.gameName = response.data.name;
      ForumsService.set($http, response.data);
      ForumsService.curFid = $scope.forum.curSubFid;
      //***//
      $scope.onTabSelected = function(args) {
        if (!angular.equals({}, ForumsService.fids)) {
          $scope.forum.curSubFid = ForumsService.fids[args];

          ForumsService.curFid = ForumsService.fids[args];
          ForumsService.curFidName = args;
        }
      }
    })
    .then(function() {
      $q.all(ForumsService.fidsLink)
        .then(function(response) {

          ForumsService.setItems(response);
          $scope.isBattle = ForumsService.isBattle;

          $scope.forum.moreNotice = ForumsService.moreNotice;
          $scope.forum.moreBattle = ForumsService.moreBattle;
          $scope.forum.moreCustomer = ForumsService.moreCustomer;

          $scope.forum.noticeFidPages = ForumsService.noticeFidPages;
          $scope.forum.battleFidPages = ForumsService.battleFidPages;
          $scope.forum.customerFidPages = ForumsService.customerFidPages;

          $rootScope.notices = ForumsService.fidsItem['noticeFid'];
          $rootScope.battles = ForumsService.fidsItem['battleFid'];
          $rootScope.customers = ForumsService.fidsItem['customerFid'];

          $scope.communicateFidTopsNum = parseInt(ForumsService.communicateFidTopsNum);
          $scope.noticeFidTopsNum = parseInt(ForumsService.noticeFidTopsNum);
          $scope.customerFidTopsNum = parseInt(ForumsService.customerFidTopsNum);
          $scope.battleFidTopsNum = parseInt(ForumsService.battleFidTopsNum);
        })
    })

  $scope.doRefresh = function(args) {
    $http.jsonp($scope.forum.curSubFidUrl() + $scope.forum.firstPage)
      .success(function(response) {
        ForumsService.setItems(response);
        if (!angular.equals({}, ForumsService.fids)) {
          switch (args) {
            case 'communicateFid':
              $rootScope.communicates = ForumsService.fidsItem[args];
              break;
            case 'noticeFid':
              $rootScope.notices = ForumsService.fidsItem[args];
              break;
            case 'battleFid':
              $rootScope.battles = ForumsService.fidsItem[args];
              break;
            case 'customerFid':
              $rootScope.customers = ForumsService.fidsItem[args];
              break;
          }
        }
        $scope.forum[args + 'Pages'] = $scope.forum.firstPage + 1;
      })
      .finally(function() {
        $scope.$broadcast('scroll.refreshComplete');
      });
  };

  $scope.loadMore = function(args) {
    $http.jsonp($scope.forum.curSubFidUrl() + $scope.forum[args + 'Pages'])
      .success(function(response) {
        $rootScope.islogin = response.isLogin;
        ForumsService.setItems(response);
        if (!($scope.forum[args + 'Pages'] < response.pages)) {
          switch (args) {
            case 'communicateFid':
              $scope.forum.moreCommunicate = false;
              break;
            case 'noticeFid':
              $scope.forum.moreNotice = false;
              break;
            case 'battleFid':
              $scope.forum.moreBattle = false;
              break;
            case 'customerFid':
              $scope.forum.moreCustomer = false;
              break;
          }
        }
        if (!angular.equals({}, ForumsService.fids)) {
          switch (args) {
            case 'communicateFid':
              $rootScope.communicates = $rootScope.communicates.concat(ForumsService.fidsItem[args]);
              break;
            case 'noticeFid':
              $rootScope.notices = $rootScope.notices.concat(ForumsService.fidsItem[args]);
              break;
            case 'battleFid':
              $rootScope.battles = $rootScope.battles.concat(ForumsService.fidsItem[args]);
              break;
            case 'customerFid':
              $rootScope.customers = $rootScope.customers.concat(ForumsService.fidsItem[args]);
              break;
          }
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
        $scope.forum[args + 'Pages'] += 1;
      });
  }

  //
  $ionicModal.fromTemplateUrl('templates/forum-post.html', {
    scope: $scope,
    animation: 'slide-in-up',
    focusFirstInput: true
  }).then(function(modal) {
    $scope.postModal = modal;
    // return modal;
  });
  $scope.openPostModal = function() {
    if ($rootScope.islogin) {
      $scope.postModal.show();
      $http.jsonp(CommonService.RootURL + 'getSubjectTypes.htm?callback=JSON_CALLBACK&fid=' + ForumsService.curFid)
        .success(function(response) {
          $scope.subjectTypes = response.threadClass;
          $scope.forums = {
            "subjectId": $scope.subjectTypes[0]
          }
        })
    }else{
      LoginService.init('templates/tab-login.html', $scope).then(function(loginModal) {
        loginModal.show();
      });
    }
  };
  $scope.closePostModal = function() {
    $scope.postModal.hide();
  };
  $scope.$on('$destroy', function() {
    $scope.postModal.remove();
  });

  // $scope.greaterThan = function(prop, val){
  //   return function(item){
  //     return item[prop] > val;
  //   }
  // }
  
  $scope.showAllTops = false;
  $scope.toggleTops = function(){
    $scope.showAllTops = !$scope.showAllTops;
  }
})

.controller('PostCtrl', function($scope, $http, $rootScope, $ionicHistory, $ionicActionSheet, $cordovaImagePicker, $cordovaCamera, $timeout, $interval, CommonService, ForumsService) {
  // $http.jsonp(CommonService.RootURL + 'getSubjectTypes.htm?callback=JSON_CALLBACK&fid=' + ForumsService.curFid)
  //   .success(function(response) {
  //     $scope.subjectTypes = response.threadClass;
  //     $scope.forums = {
  //       "subjectId": $scope.subjectTypes[0]
  //     }
  //   })

  $scope.cancel = function() {
    $ionicHistory.goBack();
  }

  /**
   *
   * 发图片帖
   */
  $scope.images_list = [];
  $scope.imgMark =[];
  // $scope.attachInfo = [];
  $scope.attachInfo = {};
  $scope.submitForums = function(forums) {
    CommonService.loading.show();
    if(!($scope.images_list.length==0)){
      upload($scope.images_list.length);

      // $timeout(function() {
      //   if ($scope.isUploadSuc) {
      //     newTopic();
      //   }
      // }, 8000);

      $scope.interval = $interval(function() {
        var times = 1;
        if (times<8) {
          times++;
        }else{
          $interval.cancel($scope.interval);
        };
        if ($scope.isUploadSuc) {
          $interval.cancel($scope.interval);
          newTopic();
        }
      }, 1000);
      // $interval.cancel(interval);

    }else{
      newTopic();
    }

    function newTopic(){
      // alert('n'+JSON.stringify($scope.attachInfo));
      $http.jsonp(CommonService.RootURL + 'postMobile.htm?callback=JSON_CALLBACK', {
        params: {
          fid: forums.subjectId.fid,
          theme: forums.theme,
          subjectId: forums.subjectId.id,
          content: forums.content,
          // attach: $scope.imgMark[$scope.images_list.length-1].aid,
          // attach:(function(){
          //   if ($scope.images_list.length) {
          //     return $scope.imgMark[$scope.images_list.length-1].aid
          //   }
          // })(),
          // attach:(function(){
          //   if ($scope.images_list.length) {
          //     var attach= ''
          //     for(var i in $scope.imgMark){
          //       attach += $scope.imgMark[$scope.images_list.length-1].aid + ',';
          //     }
          //     return attach;
          //   }
          // })(),
          attachJson: JSON.stringify($scope.attachInfo)
        }
      }).success(function(response) {
        // alert('s'+response.state);
        if (response.state) {
          CommonService.loading.hide();
          $scope.closePostModal();
          var newItem = response.thread[0];
          try {
            switch (ForumsService.curFidName) {
              case 'communicateFid':
                // $rootScope.communicates.unshift(newItem);
                $rootScope.communicates.splice(1, 0, newItem);
                break;
              case 'noticeFid':
                $rootScope.notices.splice(1, 0, newItem);
                break;
              case 'battleFid':
                $rootScope.battles.splice(1, 0, newItem);
                break;
              case 'customerFid':
                $rootScope.customers.splice(1, 0, newItem);
                break;
            }
          } catch (err) {
            console.log(err);
          }
        } else {
          CommonService.loading.hide();
          CommonService.showAlert(response);
        }
      })
    }
    
  }


  // "添加附件"Event
  $scope.addAttachment = function() {
    //nonePopover();
    $ionicActionSheet.show({
      buttons: [{
        text: '相机'
      }, {
        text: '图库'
      }],
      cancelText: '关闭',
      cancel: function() {
        return true;
      },
      buttonClicked: function(index) {
        switch (index) {
          case 0:
            appendByCamera();
            break;
          case 1:
            pickImage();
            break;
          default:
            break;
        }
        return true;
      }
    });
  };

  var pickImage = function() {
    var options = {
      maximumImagesCount: 1,
      width: 800,
      height: 800,
      quality: 80
    };

    $cordovaImagePicker.getPictures(options)
      .then(function(results) {
        if (results[0] != undefined) {
          $scope.images_list = $scope.images_list.concat({
            src: results[0],
            w: 100,
            h: 100
          });

          $http.jsonp(CommonService.RootURL + 'mobile-file-getaid.action?callback=JSON_CALLBACK')
            .success(function(response) {
              if (response.success) {
                // $scope.valiCode = response.valiCode;
                // $scope.aid = response.aid;
                $scope.imgMark = $scope.imgMark.concat({
                  valiCode:response.valiCode,
                  aid: response.aid
                });
              } else {
                // $scope.valiCode = "您未登录";
              }

            });
        }
      }, function(err) {
        console.log('err');
      });

    //多张图片选中
    // $cordovaImagePicker.getPictures(
    //  function(results) {
    //    for (var i = 0; i < results.length; i++) {
    //      $scope.images_list.push(results[i]);
    //    }
    //  },
    //  function(error) {
    //    console.log('Error: ' + error);
    //  });
  }

  var appendByCamera = function() {
    var options = {
      //这些参数可能要配合着使用，比如选择了sourcetype是0，destinationtype要相应的设置
      quality: 100, //相片质量0-100
      destinationType: Camera.DestinationType.FILE_URI, //返回类型：DATA_URL= 0，返回作为 base64 編碼字串。 FILE_URI=1，返回影像档的 URI。NATIVE_URI=2，返回图像本机URI (例如，資產庫)
      sourceType: Camera.PictureSourceType.CAMERA, //从哪里选择图片：PHOTOLIBRARY=0，相机拍照=1，SAVEDPHOTOALBUM=2。0和1其实都是本地图库
      allowEdit: false, //在选择之前允许修改截图
      encodingType: Camera.EncodingType.JPEG, //保存的图片格式： JPEG = 0, PNG = 1
      // targetWidth: 200, //照片宽度
      // targetHeight: 200, //照片高度
      mediaType: 0, //可选媒体类型：圖片=0，只允许选择图片將返回指定DestinationType的参数。 視頻格式=1，允许选择视频，最终返回 FILE_URI。ALLMEDIA= 2，允许所有媒体类型的选择。
      cameraDirection: 0, //枪后摄像头类型：Back= 0,Front-facing = 1
      popoverOptions: CameraPopoverOptions,
      saveToPhotoAlbum: true //保存进手机相册
    };

    $cordovaCamera.getPicture(options)
      .then(function(imageData) {
        if (imageData[0] != undefined) {
          $scope.images_list = $scope.images_list.concat({
            src: imageData,
            w: 100,
            h: 100
          });
          $http.jsonp(CommonService.RootURL + 'mobile-file-getaid.action?callback=JSON_CALLBACK')
            .success(function(response) {
              if (response.success) {
                // $scope.valiCode = response.valiCode;
                // $scope.aid = response.aid;
                $scope.imgMark = $scope.imgMark.concat({
                  valiCode:response.valiCode,
                  aid: response.aid
                });
              } else {
                // $scope.valiCode = "您未登录";
              }

            });
        }
        // CommonJs.AlertPopup(imageData);
        // image.src = "data:image/jpeg;base64," + imageData;
      }, function(err) {
        // CommonJs.AlertPopup(err.message);
        console.log('err');
      });
  }

  //删除附件
  $scope.delPic = function(){

  }

  // 上传文件
  function upload(filesNum) {

    //新建文件上传选项，并设置文件key，name，type
    var options = new FileUploadOptions();
        options.fileKey = "ffile";
    var imageUrl = $scope.images_list[filesNum-1].src;
        options.fileName = imageUrl.substr(imageUrl.lastIndexOf('/') + 1);
        options.mimeType = "image/jpeg";
    //用params保存其他参数，例如昵称，年龄之类
    var params = {};
        params['aid'] = $scope.imgMark[filesNum-1].aid;
        params['valiCode'] = $scope.imgMark[filesNum-1].valiCode;
    //把params添加到options的params中
        options.params = params;
    //新建FileTransfer对象
    var ft = new FileTransfer();
    //上传文件
        ft.upload(
          imageUrl,
          encodeURI(CommonService.RootURL + 'mobile-file-upload.action'), //把图片及其他参数发送到这个URL，相当于一个请求，在后台接收图片及其他参数然后处理
          uploadSuccess,
          uploadError,
          options);
    //upload成功的话
    function uploadSuccess(r) {
      var resp = JSON.parse(r.response);
      if (resp.success) {
        var uploadFiles = {};
            uploadFiles[$scope.imgMark[filesNum-1].aid] = resp.picName;
        // var attachInfo = JSON.stringify(uploadFiles);
        // $scope.attachInfo = $scope.attachInfo.concat(uploadFiles);
        $scope.attachInfo = angular.extend($scope.attachInfo,uploadFiles);
        filesNum--;
        if (filesNum > 0) {
          upload(filesNum);
        } else {
          $scope.isUploadSuc = true;
        };

      } else {
        alert(r.response.msg);
      }
      var resp = JSON.parse(r.response);
    }
    //upload失败的话
    function uploadError(error) {}
  }
  //
})

.controller('ThreadCtrl', function($scope, $http, $rootScope, $stateParams, $ionicActionSheet, $ionicScrollDelegate, $cordovaClipboard, $ionicPopup, $ionicModal, $ionicSlideBoxDelegate, CommonService, LoginService, ThreadService) {
  $scope.thread = {
    url: CommonService.RootURL + 'getNewThreadInfo.htm?callback=JSON_CALLBACK&tid=' + $stateParams.tid + '&page=',
    imgUrl: CommonService.RootURL + 'getImages.htm?callback=JSON_CALLBACK&tid=' + $stateParams.tid,
    firstPage: 1,
    currentPage: 1
  };

  $rootScope.islogin=[];
  $scope.header = [];
  // $scope.owner = [];
  $rootScope.replys = [];

  $scope.moreThreadLoaded = true;
  $scope.landlord = false;
  $scope.order = false;
  $scope.faces = false;

  $scope.doRefresh = function() {
    $scope.moreThreadLoaded = true;
    $scope.landlord = false;
    $scope.order = false;

    $http.jsonp($scope.thread.url + $scope.thread.firstPage)
      .success(function(response) {
        ThreadService.set(response);
        // $scope.owner = ThreadService.get('first');
        $rootScope.replys = ThreadService.get('replyThreads');
        $scope.thread.pages = ThreadService.get('pages');
        if (ThreadService.get('pages') == 1 || !($scope.thread.currentPage - 1 < ThreadService.get('pages'))) {
          $scope.moreThreadLoaded = false;
        }
        $scope.thread.currentPage = $scope.thread.firstPage + 1;
      })
      .finally(function() {
        $scope.$broadcast('scroll.refreshComplete');
      });
  };

  $scope.loadMore = function() {
    /**
     * authorid=&orderRule=
     * authorid=null，或者空，不传，都为正常，传了
     * orderRule=0，不传，为空则正常，=1则为倒叙
     * faceFilter=0，默认情况过滤 faceFilter=1,不过滤纯表情
     */
    var threadUrl;
    if ($scope.landlord) {
      threadUrl = $scope.thread.url + $scope.thread.currentPage + '&authorid=' + ThreadService.get('replyThreads')[0]['authorid'];
    } else if ($scope.order) {
      threadUrl = $scope.thread.url + $scope.thread.currentPage + '&orderRule=1';
    } else if ($scope.faces) {
      threadUrl = $scope.thread.url + $scope.thread.currentPage + '&faceFilter=1';
    } else {
      threadUrl = $scope.thread.url + $scope.thread.currentPage;
    };

    $http.jsonp(threadUrl)
      .success(function(response) {
        // console.log('first');
        ThreadService.set(response);
        if (ThreadService.get('pages') == 1 || !($scope.thread.currentPage < ThreadService.get('pages'))) {
          $scope.moreThreadLoaded = false;
        }
        // if (ThreadService.thread.hasOwnProperty('first')) {
        //   $scope.owner = ThreadService.get('first');
        // }
        // $rootScope.replys = $rootScope.replys.concat(ThreadService.get('replyThreads'));
        $rootScope.replys = ThreadService.get('replyThreads');
        $rootScope.islogin = response.isLogin;
        $scope.header = response.header;
        $scope.thread.pages = response.pages;
        $scope.$broadcast('scroll.infiniteScrollComplete');
        $scope.thread.currentPage += 1;

      })
  };

  //
  $ionicModal.fromTemplateUrl('templates/forum-reply.html', {
    scope: $scope,
    animation: 'slide-in-up',
    focusFirstInput: true
  }).then(function(modal) {
    $scope.replyModal = modal;
    // return modal;
  });
  $scope.openReplyModal = function(replyType, floor) {
    ThreadService.thread.quoteReply = replyType;
    ThreadService.thread.qutoeReplyFloor = floor;
    if ($rootScope.islogin) {
      $scope.replyModal.show();
    }else{
      LoginService.init('templates/tab-login.html', $scope).then(function(loginModal) {
        loginModal.show();
      });
    }
  };
  $scope.closeReplyModal = function() {
    $scope.replyModal.hide();
  };
  $scope.$on('$destroy', function() {
    $scope.replyModal.remove();
  });

  //
  $scope.sheetObj = {
    'showLandlord':true,
    'showFace':true,
    'showOrder':true,
    0:['只看楼主','显示全部'],
    1:['显示表情','过滤表情'],
    2:['倒序浏览','正序浏览'],
    3:['收藏'],
    4:['举报']
  }
  $scope.moreSheet = function() {
    $scope.hideSheet = $ionicActionSheet.show({
      buttons: [{
        text: (function(){
          return $scope.sheetObj.showLandlord ? $scope.sheetObj[0][0] : $scope.sheetObj[0][1]
        })()
      }, {
        text: (function(){
          return $scope.sheetObj.showFace ? $scope.sheetObj[1][0] : $scope.sheetObj[1][1]
        })()
      }, {
        text: (function(){
          return $scope.sheetObj.showOrder ? $scope.sheetObj[2][0] : $scope.sheetObj[2][1]
        })()
      }, {
        text: $scope.sheetObj[3][0]
      }, {
        text: $scope.sheetObj[4][0]
      }],
      cancelText: '取消',
      cancel: function() {
        // add cancel code..
      },
      buttonClicked: function(index) {
        /**
         * 0-只看楼主
         * 1-过滤表情
         * 2-倒叙浏览
         * 3-收藏
         * 4-举报
         */
        if (index == 0) {
            $http.jsonp($scope.thread.url + $scope.thread.firstPage, {
              params: {
                authorid: (function () {
                  return $scope.sheetObj.showLandlord ? ThreadService.get('replyThreads')[0]['authorid'] :'';
                })()
              }
            }).success(function(response) {
              $scope.landlord = true;
              $scope.showFace = false;
              $scope.order = false;
              $scope.sheetObj.showLandlord ? ($scope.sheetObj.showLandlord = false):($scope.sheetObj.showLandlord = true);
              ThreadService.thread.replyThreads = [];
              $scope.moreThreadLoaded = true;
              $ionicScrollDelegate.scrollTop();
              $scope.thread.currentPage = 2;
              $scope.thread.pages = response.pages;
              ThreadService.set(response);
              $rootScope.replys = ThreadService.get('replyThreads');
              if (ThreadService.get('pages') == 1 || !($scope.thread.currentPage - 1 < ThreadService.get('pages'))) {
                $scope.moreThreadLoaded = false;
              }
            });
          return true;
        } else if (index == 1) {
          $http.jsonp($scope.thread.url + $scope.thread.firstPage, {
              params: {
                faceFilter: (function () {
                  return $scope.sheetObj.showFace ? 1: 0;
                })()
              }
            }).success(function(response) {
              $scope.showFace = true;
              $scope.order = false;
              $scope.Landlord = false;
              $scope.sheetObj.showFace ? ($scope.sheetObj.showFace = false):($scope.sheetObj.showFace = true);
              ThreadService.thread.replyThreads = [];
              $scope.moreThreadLoaded = true;
              $ionicScrollDelegate.scrollTop();
              $scope.thread.currentPage = 2;
              $scope.thread.pages = response.pages;
              ThreadService.set(response);
              $rootScope.replys = ThreadService.get('replyThreads');
              if (ThreadService.get('pages') == 1 || !($scope.thread.currentPage - 1 < ThreadService.get('pages'))) {
                $scope.moreThreadLoaded = false;
              }
            });
          return true;

        } else if (index == 2) {
          $http.jsonp($scope.thread.url + $scope.thread.firstPage, {
            params: {
              orderRule: (function () {
                return $scope.sheetObj.showOrder ? 1 :''
              })()
            }
          }).success(function(response) {
            $scope.order = true;
            $scope.landlord = false;
            $scope.showFace = false;
            $scope.sheetObj.showOrder ? ($scope.sheetObj.showOrder = false):($scope.sheetObj.showOrder = true);
            ThreadService.thread.replyThreads = [];
            $scope.moreThreadLoaded = true;
            $ionicScrollDelegate.scrollTop();
            $scope.thread.currentPage = 2;
            $scope.thread.pages = response.pages;
            ThreadService.set(response);
            $rootScope.replys = ThreadService.get('replyThreads');
            if (ThreadService.get('pages') == 1 || !($scope.thread.currentPage - 1 < ThreadService.get('pages'))) {
              $scope.moreThreadLoaded = false;
            }
          });
          return true;
        } else if (index == 3) {
          $http.jsonp(CommonService.RootURL + 'mobileCollect.htm?callback=JSON_CALLBACK', {
            params: {
              tid: ThreadService.get('replyThreads')[0]['tid']
            }
          }).success(function(response) {
            CommonService.showAlert(response);
          });
          return true;
        } else if (index == 4) {
          ThreadService.showConfirm();
          return true;
        }
      }
    });
  }

  $scope.copyText = function(value) {
    alert(navigator.appVersion);
    // $ionicPopup.show({
    //   title: '<b padding="10">操作</b>',
    //   scope: $scope,
    //   buttons: [{
    //     text: '复制',
    //     type: 'button',
    //     onTap: function(e) {
    //       $cordovaClipboard.copy(value).then(function() {
    //         // alert("Copied text");
    //       }, function() {
    //         // alert("There was an error copying");
    //       });
    //     }
    //   }]
    // });
  }
  //====================================================
  // $scope.aImages = [{
  //   'src': 'img/auction.png',
  //   'msg': ''
  // }, {
  //   'src': 'img/collect.png',
  //   'msg': ''
  // }, {
  //   'src': 'img/gift.png',
  //   'msg': ''
  // }, {
  //   'src': 'img/help.png',
  //   'msg': ''
  // }];
  
  //$scope.aImages = [];
  //$ionicModal.fromTemplateUrl('image-modal.html', {
  //  scope: $scope,
  //  animation: 'slide-in-up'
  //}).then(function(modal) {
  //  $scope.ImageModal = modal;
  //  $http.jsonp($scope.thread.imgUrl)
  //    .success(function(response) {
  //      $scope.aImages = response.imageList;
  //    })
      // return modal;
  //});

  $scope.openImageModal = function() {
    // console.log('openModal');
    //  $ionicSlideBoxDelegate.slide(0);
    //  $scope.ImageModal.show();
  };

  $scope.closeImageModal = function() {
    // console.log('closeModal');
    //$scope.ImageModal.hide();
  };

  // Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function() {
    //$scope.ImageModal.remove();
  });
  // Execute action on hide modal
  $scope.$on('modal.hide', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });
  $scope.$on('modal.shown', function() {
    // console.log('Modal is shown!');
  });

  // Call this functions if you need to manually control the slides
  $scope.next = function() {
    //$ionicSlideBoxDelegate.next();
  };

  $scope.previous = function() {
    //$ionicSlideBoxDelegate.previous();
  };

  $scope.goToSlide = function(index) {
    // console.log('goToSlide');
    //$scope.modal.show();
    //$ionicSlideBoxDelegate.slide(index);
  }

  // Called each time the slide changes
  $scope.slideChanged = function(index) {
    //$scope.slideIndex = index;
  };

})

.controller('ReplyCtrl', function($scope, $http, $rootScope, CommonService, ThreadService) {
  $scope.reply = function(forums) {
    var content;
    if (ThreadService.thread.quoteReply == 'quote') {
      var quoteReplyFloor = ThreadService.get('replyThreads')[ThreadService.get('qutoeReplyFloor')];
      var quoteContent = (quoteReplyFloor['author'] + '发表于' +
        quoteReplyFloor['postDate']).replace(/\n|\r/g, '');
      if (quoteReplyFloor['content'].toString().length > 25) {
        quoteReplyFloor['content'] = quoteReplyFloor['content'].substring(0, 24);
        quoteReplyFloor['content'] += '...';
      }
      quoteContent += quoteReplyFloor['content'];
      content = '[quote]' + quoteContent + '[/quote]' + forums.content;
    } else {
      content = forums.content;
    }
    $http.jsonp(CommonService.RootURL + 'replyNewThread.htm?callback=JSON_CALLBACK', {
      params: {
        tid: ThreadService.get('replyThreads')[0]['tid'],
        content: content
      }
    }).success(function(response) {
      if (response.state) {
        $scope.closeReplyModal();
        var newItem = response.replyThreads[0];
        $rootScope.replys.push(newItem);
      } else {
        CommonService.showAlert(response);
      }
    })
  }
    // $scope.cancel = function() {
    //   $ionicHistory.goBack();
    // }
})

.controller('PersonalCtrl', function($scope, $http, $rootScope, CommonService, LoginService) {
  if (!$rootScope.islogin) {
    LoginService.init('templates/tab-login.html', $scope).then(function(loginModal) {
      loginModal.show();
    });
  }

  $http.jsonp(CommonService.RootURL + 'center-user-info.htm?callback=JSON_CALLBACK')
    .then(function(response) {
      $rootScope.islogin = response.data.state;
      $scope.userInfo = response.data;
    })
})

.controller('MyThreadCtrl', function($scope, $http, CommonService) {
  $http.jsonp(CommonService.RootURL + 'getMyThreadsByMobile.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.myThreads = response.threads;
    })
})

.controller('MyReplyCtrl', function($scope, $http, CommonService) {
  $http.jsonp(CommonService.RootURL + 'getMyPostsByMobile.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.myReplys = response.threads;
    })
})

.controller('CollectCtrl', function($scope, $http, CommonService) {
  $http.jsonp(CommonService.RootURL + 'getCollections.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.myCollections = response.threads;
    })
})

.controller('RoleCtrl', function($scope, $http, CommonService) {
  $http.jsonp(CommonService.RootURL + 'center.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.myRoles = response.myRoles;
    })
})

.controller('LoginCtrl', function($scope, $http, $rootScope, $ionicModal, CommonService, LoginService) {
  $scope.login = function(user) {
    $scope.userParams = 'username=' + user.name + '&password=' + user.password + '&command=login';
    $http.jsonp(CommonService.RootURL + 'mb-user.htm?callback=JSON_CALLBACK', {
      params: {
        token: encryptedString(CommonService.RSAKey(), encodeURIComponent($scope.userParams))
      }
    }).success(function(response) {
      if (response.state) {
        $rootScope.islogin = true;
        $scope.closeLoginModal('true');
      } else {
        CommonService.showAlert(response);
      }
    })
  }
  // 
  $ionicModal.fromTemplateUrl('templates/tab-regist.html', {
    scope: $scope,
    animation: 'slide-in-up',
    focusFirstInput: true
  }).then(function(modal) {
    $scope.registModal = modal;
    // return modal;
  });
  $scope.openRegistModal = function() {
    $scope.registModal.show();
  };
  $scope.closeRegistModal = function() {
    $scope.registModal.hide();
  };
  $scope.$on('$destroy', function() {
    $scope.registModal.remove();
  });
})

.controller('RegistCtrl', function($scope, $http, $rootScope, $ionicModal, CommonService, RegistService) {
  $scope.user = {
    'name': '',
    'password': '',
    'validate': '',
  };
  $scope.userExist = true;
  $scope.validateUrl = CommonService.validateUrl;
  // 
  $scope.validate = function() {
    CommonService.setAttr(CommonService.validateID);
    RegistService.emptyValidate($scope);
  };
  // 
  $scope.checkName = function(user) {
    if (user != '' && user != undefined && RegistService.checkName(user)) {
      $http.jsonp(CommonService.RootURL + 'mb-userExist.htm?callback=JSON_CALLBACK', {
        params: {
          username: user
        }
      }).success(function(response) {
        $scope.errorName = response.message;
        $scope.userExist = response.state;
      })
    }
  }
  // 
  $scope.regist = function(user) {
    $scope.registArgs = 'username=' + user.name + '&password=' + user.password + '&validationCode=' + user.validate + '&command=regist';
    $http.jsonp(CommonService.RootURL + 'mb-user.htm?callback=JSON_CALLBACK', {
      params: {
        token: encryptedString(CommonService.RSAKey(), encodeURIComponent($scope.registArgs))
      }
    }).success(function(response) {
      if (response.state) {
        $rootScope.islogin = true;
        $scope.closeRegistModal();
        $scope.closeLoginModal();
      } else {
        CommonService.showAlert(response);
        RegistService.emptyValidate($scope);
      }
    })
  }
  // 
  $ionicModal.fromTemplateUrl('templates/contract.html', {
    scope: $scope,
    animation: 'slide-in-up',
    focusFirstInput: true
  }).then(function(modal) {
    $scope.contractModal = modal;
    // return modal;
  });
  $scope.openContractModal = function() {
    $scope.contractModal.show();
  };
  $scope.closeContractModal = function() {
    $scope.contractModal.hide();
  };
  $scope.$on('$destroy', function() {
    $scope.contractModal.remove();
  });
  // 
})

.controller('SocialCtrl', function($scope, $http, $rootScope, $state, CommonService, LoginService) {
  if (!$rootScope.islogin) {
    LoginService.init('templates/tab-login.html', $scope).then(function(loginModal) {
      loginModal.show();
    });
  }

  $http.jsonp(CommonService.RootURL + 'mb-sysmsg.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.sysNotices = response.pms;
    })
})

.controller('SetCtrl', function($scope, $http, $rootScope, $state, CommonService, LoginService, SetService) {
  if (!$rootScope.islogin) {
    LoginService.init('templates/tab-login.html', $scope).then(function(loginModal) {
      loginModal.show();
    });
  }

  $http.jsonp(CommonService.RootURL + 'mb-getBindedPhone.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.isBind = response.isBinded;
      $scope.phoneNumber = response.phoneNumber;
    })

  $scope.clearCache = function(){
    var response = {
      message:'确定要清除缓存吗？'
    };
    SetService.showConfirm(response);
  }

  $scope.logout = function() {
    $http.jsonp(CommonService.RootURL + 'mb-logout.htm?callback=JSON_CALLBACK')
      .success(function(response) {
        $rootScope.islogin = false;
        $state.go('tab.game');
      })
  }
})

.controller('NicknameCtrl', function($scope, $http, CommonService) {
  $http.jsonp(CommonService.RootURL + 'personal-index.htm?callback=JSON_CALLBACK')
    .success(function(response) {
      $scope.isChanged = response.isChanged;
      $scope.name = response;
    });

  $scope.changeNickname = function(user) {
    $http.jsonp(CommonService.RootURL + 'mb-personal-update.htm?callback=JSON_CALLBACK', {
      params: {
        nickname: user.nickname,
        personalSign: ''
      }
    }).success(function(response) {
      response.state ? $scope.isChanged = response.state : '';
      CommonService.showAlert(response);
    })
  }
})

.controller('PasswordCtrl', function($scope, $http, $rootScope, CommonService) {
  $scope.changePassword = function(user) {
    $http.jsonp(CommonService.RootURL + 'mb-changePwd.htm?callback=JSON_CALLBACK', {
      params: {
        token: encryptedString(CommonService.RSAKey(), encodeURIComponent('oldPwd=' + user.password + '&newPwd=' + user.newPassword))
      }
    }).success(function(response) {
      if (response.state) {
        $scope.isChanged = response.state;
        $rootScope.islogin = false;
      };
      CommonService.showAlert(response);
    })
  }
})

.controller('MobileCtrl', function($scope, $http, $timeout, CommonService, MobileService) {

  // var phoneRegExp = /^0?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
  $scope.validateUrl = CommonService.validateUrl;
  $scope.second = '短信码';
  $scope.isFetch = false;
  $scope.isBind = false;

  $scope.user = {
    'tel': '',
    'validate': '',
    'MsgCode': ''
  };

  function countDown(i) {
    if (i >= 0) {
      $scope.second = i;
      i--;
    } else {
      $scope.second = '短信码';
      $scope.isFetch = false;
      return;
    }
    $timeout(function() {
      countDown(i);
      $scope.isFetch = true;
    }, 1000);
  }

  $scope.validate = function() {
    CommonService.setAttr(CommonService.validateID);
    MobileService.emptyValidate($scope);
  };
  //====================================================
  // document.addEventListener('deviceready', fetchMsgCode);

  // function fetchMsgCode() {
  //   alert(1);
  //   if (!angular.equals({}, $scope.user)) {
  //     $scope.isFetch = true;
  //   }
  // }
  
  $scope.MsgCode = function(user) {
    $http.jsonp(CommonService.RootURL + 'mb-getBindCode.htm?callback=JSON_CALLBACK', {
      params: {
        phone: user.tel,
        validateCode: user.validate
      }
    }).success(function(response) {
      if (response.state) {
        countDown(60);
        $scope.isFetch = false; //倒计时禁止在次发请求
      } else {
        MobileService.emptyValidate($scope);
        CommonService.showAlert(response);
      }
    })
  }

  $scope.bindMobile = function(user) {
    $http.jsonp(CommonService.RootURL + 'mb-bindPhone.htm?callback=JSON_CALLBACK', {
      params: {
        phone: user.tel,
        code: user.MsgCode
      }
    }).success(function(response) {
      if (response.state) {

      } else {
        CommonService.showAlert(response);
      }
    })
  }
  //
});
